/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.artistsearchoop;

import java.util.Scanner;

/**
 *
 * @author user-pc
 */
public class ArtistSearchOop {
    public static void main(String[] args){
        try{
            ArtistTable.saleSummary();
            subclass.salesSummary(0);
        }
        catch(Exception ex){
            System.out.print("Error: "+ex);
        }
        
    

        
    }
}
