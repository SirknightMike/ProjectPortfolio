/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.artistsearchoop;

/**
 *
 * @author user-pc
 */
public abstract class ArtistTable implements Interface1{
    int rowSum;
    int ColSum;
    public static int [][] artistSales = { {900000,800000,500000},{700000,500000,500000},{800000,100000,50000},{100000,200000,200000},{300000,100000,50000} };
    public static String [] artistNames = { "Master KG", "DJ B Coffee", "Bruno Mars", "F Fighters", "T Swift" };
    ArtistTable(int rowSum, int ColSum){
        this.rowSum = rowSum;
        this.ColSum = ColSum;
    }
    
    public static void saleSummary(){
       
        int totalDVDSold =0;
        int totalBluraySold =0;
        int totalCDSold = 0;
        int counter = 0;
        for(int i =0;i <5;i++){
            totalDVDSold = totalDVDSold + artistSales[i][0];
            totalBluraySold = totalBluraySold + artistSales[i][1];
            totalCDSold = totalCDSold +artistSales[i][2];
            if(i==0){
                System.out.println("______________________________________________________________");
            }
            System.out.printf("%-15s%-15d%-15d%-15d\n", artistNames[i], artistSales[counter][0],artistSales[counter][1], artistSales[counter][2]);
            if(i==4){
                System.out.println("___________________________________________________________________");
                System.out.printf("%-15s%-15d%-15d%-15d\n","Total",totalDVDSold, totalBluraySold,totalCDSold);
            }
            counter++;
            
        }
    }
}