/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.artistsearchoop;

import java.util.Scanner;

/**
 *
 * @author user-pc
 */
public abstract class subclass extends ArtistTable{
    int index;
    
    
    subclass(int index,int rowSum,int ColSum){
        super(rowSum,ColSum);
        this.index = index;
    }
    
    public static void salesSummary(int artistPosition){
        Scanner myScanner = new Scanner(System.in);
        
        for(int userAtempts= 0; userAtempts < 6;){
            int totalSales = 0;
            System.out.println("Please Enter a Number between 0 and 6: ");
            artistPosition = myScanner.nextInt();
            
            if(artistPosition < 0){
                break;
            }
            switch(artistPosition){
                case 0:
                System.out.println("Artist Name: "+artistNames[artistPosition]);
                System.out.println("Artist CD sale: "+artistSales[artistPosition][2]);
                System.out.println("Artist DVD Sale: "+artistSales[artistPosition][0]);
                System.out.println("Artist Blu Ray Sale: "+artistSales[artistPosition][1]);
                for(int count =0;count <3;count++){
                    totalSales = totalSales + artistSales[artistPosition][count];
                    if(count == 2){
                        System.out.println("Artist total of CD,DVD, and Blue Ray Sale: "+totalSales);
                        
                    }
                    
                }
                break;
                case 1:
                    System.out.println("Artist Name: "+artistNames[artistPosition]);
                    System.out.println("Artist CD sale: "+artistSales[artistPosition][2]);
                    System.out.println("Artist DVD Sale: "+artistSales[artistPosition][0]);
                    System.out.println("Artist Blu Ray Sale: "+artistSales[artistPosition][1]);
                    for(int count =0;count <3;count++){
                        totalSales = totalSales + artistSales[artistPosition][count];
                        if(count == 2){
                            System.out.println("Artist total of CD,DVD, and Blue Ray Sale: "+totalSales);

                        }

                    }
                    break;
                case 2:
                    System.out.println("Artist Name: "+artistNames[artistPosition]);
                    System.out.println("Artist CD sale: "+artistSales[artistPosition][2]);
                    System.out.println("Artist DVD Sale: "+artistSales[artistPosition][0]);
                    System.out.println("Artist Blu Ray Sale: "+artistSales[artistPosition][1]);
                    for(int count =0;count <3;count++){
                        totalSales = totalSales + artistSales[artistPosition][count];
                        if(count == 2){
                            System.out.println("Artist total of CD,DVD, and Blue Ray Sale: "+totalSales);
                        }
                    }
                    break;
                case 3:
                    System.out.println("Artist Name: "+artistNames[artistPosition]);
                    System.out.println("Artist CD sale: "+artistSales[artistPosition][2]);
                    System.out.println("Artist DVD Sale: "+artistSales[artistPosition][0]);
                    System.out.println("Artist Blu Ray Sale: "+artistSales[artistPosition][1]);
                    for(int count =0;count <3;count++){
                        totalSales = totalSales + artistSales[artistPosition][count];
                        if(count == 2){
                            System.out.println("Artist total of CD,DVD, and Blue Ray Sale: "+totalSales);
                        }
                    }
                    break;
                case 4:
                    System.out.println("Artist Name: "+artistNames[artistPosition]);
                    System.out.println("Artist CD sale: "+artistSales[artistPosition][2]);
                    System.out.println("Artist DVD Sale: "+artistSales[artistPosition][0]);
                    System.out.println("Artist Blu Ray Sale: "+artistSales[artistPosition][1]);
                    for(int count =0;count <3;count++){
                        totalSales = totalSales + artistSales[artistPosition][count];
                        if(count == 2){
                            System.out.println("Artist total of CD,DVD, and Blue Ray Sale: "+totalSales);
                        }
                    }
                    break;
                case 5:
                    System.out.println("Artist Name: "+artistNames[artistPosition]);
                    System.out.println("Artist CD sale: "+artistSales[artistPosition][2]);
                    System.out.println("Artist DVD Sale: "+artistSales[artistPosition][0]);
                    System.out.println("Artist Blu Ray Sale: "+artistSales[artistPosition][1]);
                    for(int count =0;count <3;count++){
                        totalSales = totalSales + artistSales[artistPosition][count];
                        if(count == 2){
                            System.out.println("Artist total of CD,DVD, and Blue Ray Sale: "+totalSales);
                        }
                    }
                    break;
                default:
                    userAtempts++;
                        if(userAtempts == 6){
                                break;
                                }else{

                                        }
                }        
        }
    }
}
