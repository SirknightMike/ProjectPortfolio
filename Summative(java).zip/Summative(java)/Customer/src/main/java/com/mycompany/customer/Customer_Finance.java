/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.customer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author user-pc
 */
public class Customer_Finance {
    
    
    
    public Customer_Finance(){
        Customer myObj = new Customer();
        myObj.setCustomerName(JOptionPane.showInputDialog(null, "What is your name?: "));
        
        try{
           myObj.setContactNumber(JOptionPane.showInputDialog(null, "Please enter the customer contact number: "));
            
            
        }catch(Exception ex){
            System.out.println("Please enter a Number");
        }
        
        try{
            myObj.setProductPrice(Integer.parseInt(JOptionPane.showInputDialog(null, "Please enter the Price of the Product: ")));
        }catch(Exception ex){
            System.out.println("Please enter the Price of the Product.");
        }
        
        try{
            myObj.setNumberReplaymentMonths(Integer.parseInt(JOptionPane.showInputDialog(null, "Please enter the number of repayment months: ")));
        }catch(Exception ex){
            System.out.println("Please enter the number of Repayment.");
        }
        
        
        JOptionPane.showMessageDialog(null, "Customer Name:"+Customer.customerName+"\n Customer Contact:"+Customer.contactNumber+"\n Product Amount:R "+Customer.productPrice+"\n Repayment Months:"+Customer.numberRepaymentMonths+"\n Monthly Repayment:R "+Finance_Period.calculate_replayment(Customer.productPrice, Customer.numberRepaymentMonths)+"\n Total Due:R "+Finance_Period.totalCost);
        
    }
}
