/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.customer;

import javax.swing.JFrame;

/**
 *
 * @author user-pc
 */
public class Customer {
    public static String customerName;
    public static String contactNumber;
    public static int productPrice;
    public static int numberRepaymentMonths;
    public static int monthlyReplayment;
    
    public static double monthlyReplaymentTotal;
    
    
    
    public static void main(String[] args) {
        new Customer_Finance();
    }
    
    public String getCustomerName(){
        return this.customerName;
    }
    
    public void setCustomerName(String customerName){
        this.customerName = customerName;
    }
    
    public String getContactNumber(){
        return this.contactNumber;
    }
    
    public void setContactNumber(String contactNumber){
        this.contactNumber = contactNumber;
    }
    
    public int getProductPrice(){
        return this.productPrice;
    }
    
    public void setProductPrice(int productPrice){
        this.productPrice = productPrice;
    }
    
    public int getNumberReplaymentMonths(){
        return this.numberRepaymentMonths;
    }
    
    public void setNumberReplaymentMonths(int numberReplaymentMonths){
        this.numberRepaymentMonths = numberReplaymentMonths;
    }
    
    public static double calculate_replayment(int getProductPrice, int getNumberReplaymentMonths){
        monthlyReplaymentTotal = getProductPrice/getNumberReplaymentMonths;
        return monthlyReplaymentTotal;
    }
}
