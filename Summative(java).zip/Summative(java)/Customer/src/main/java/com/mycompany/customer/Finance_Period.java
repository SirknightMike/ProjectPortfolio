/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.customer;

/**
 *
 * @author user-pc
 */

public class Finance_Period extends Customer{
    public static double totalCost;
    
    
    public static double calculate_replayment(int getProductPrice, int getNumberReplaymentMonths){
        if(getNumberReplaymentMonths > 3){
            double interestTotal = getProductPrice*0.25;
            totalCost = getProductPrice + interestTotal;
            monthlyReplaymentTotal = totalCost/getNumberReplaymentMonths;
            
        }else{
            return Customer.calculate_replayment(getProductPrice, getNumberReplaymentMonths);
        }
        return monthlyReplaymentTotal;
    }
}
