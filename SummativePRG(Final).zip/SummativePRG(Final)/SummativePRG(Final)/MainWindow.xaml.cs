﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Reflection.Metadata;

namespace SummativePRG_Final_
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // -------------------------------------------------------------------------------
        // Variables
        public static int Admin;
        public static int year;
        public static int month;
        public static Period Sale;
        // Order Object Array
        public static Order[] AddToOrder = new Order[7];
        // Coffee Counter
        public static int coffeeCounter = 0;
        // Manager Object
        Manager manager;
        // Time Period Enum
        public enum Period
        {
            DAY,
            MONTH,
            YEAR
        }
        // -------------------------------------------------------------------------------
        // Management TAB
        public MainWindow()
        {
            InitializeComponent();
            try
            {
                UpdateTime();
                manager = new Manager();
            }
            catch (Exception)
            {
                _ = MessageBox.Show("Please Pick a Sale and a Date!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        // -------------------------------------------------------------------------------
        // Update Time on the textbox
        private void UpdateTime()
        {
            try
            {
                managementTxtBox.Text = "";
                orderSummaryTextBox.Text = "";
                string Month = "";
                switch (DateTime.Now.Month)
                {
                    case 1:
                        Month = "Jan";
                        break;
                    case 2:
                        Month = "Feb";
                        break;
                    case 3:
                        Month = "Mar";
                        break;
                    case 4:
                        Month = "Apr";
                        break;
                    case 5:
                        Month = "May";
                        break;
                    case 6:
                        Month = "Jun";
                        break;
                    case 7:
                        Month = "Jul";
                        break;
                    case 8:
                        Month = "Aug";
                        break;
                    case 9:
                        Month = "Sep";
                        break;
                    case 10:
                        Month = "Oct";
                        break;
                    case 11:
                        Month = "Nov";
                        break;
                    case 12:
                        Month = "Dec";
                        break;
                    default:
                        break;
                }

                int Day = DateTime.Now.Day;
                int Year = DateTime.Now.Year;

                managementTxtBox.Text += DateTime.Now.DayOfWeek + ", " + Month + " " + Day + " " + Year + ", " + DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.TimeOfDay.ToString().Split(':')[2].Split('.')[0] + "\n\n";
                orderSummaryTextBox.Text += managementTxtBox.Text;
                orderSummaryTextBox.AppendText("Qtity".PadRight(20) + " | Description".PadRight(80) + " | Price | Total\n");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
        // -------------------------------------------------------------------------------
        // B1 Button Save To TXT File
        private void Save_btn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Admin == 1)
                {
                    bool Daily = (bool)dailyRBtn.IsChecked;
                    bool Monthly = (bool)monthlyRBtn.IsChecked;
                    bool Yearly = (bool)yearlyRBtn.IsChecked;

                    if (Daily)
                    {
                        Sale = Period.DAY;
                        year = managementDatePicker.SelectedDate.Value.Year;
                        month = managementDatePicker.SelectedDate.Value.Month;
                        manager.SaveToTXT(managementDatePicker.SelectedDate.Value.Day);
                        _ = MessageBox.Show("Daily Data Saved to BackUpSale.txt", "Saved!", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else if (Monthly)
                    {
                        Sale = Period.MONTH;
                        year = managementDatePicker.SelectedDate.Value.Year;
                        manager.SaveToTXT(managementDatePicker.SelectedDate.Value.Month);
                        _ = MessageBox.Show("Monthly Data Saved to BackUpSale.txt", "Saved!", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else if (Yearly)
                    {
                        Sale = Period.YEAR;
                        manager.SaveToTXT(managementDatePicker.SelectedDate.Value.Year);
                        _ = MessageBox.Show("Yearly Data Saved to BackUpSale.txt", "Saved!", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        _ = MessageBox.Show("Please Pick a Sale and a Date!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                else
                {
                    Validation validate = new Validation();
                    validate.Show();
                    Close();
                }
            }
            catch (Exception)
            {
                _ = MessageBox.Show("Please Pick a Sale and a Date!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        // -------------------------------------------------------------------------------
        // B2 Button Save Information From TXT BOX to PDF DOC
        private void Print_btn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Admin != 1)
                {
                    _ = MessageBox.Show("Please Display Data fist in the textbox!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    // TODO: Save textbox to a document
                    string path = "Document.pdf";
                    Document doc = new Document();

                    Page page = doc.Pages.Add();
                    page.Paragraphs.Add(new Aspose.Pdf.Text.TextFragment(managementTxtBox.Text));

                    doc.Save(path);
                    _ = MessageBox.Show("Data Saved to Document.pdf", "Saved!", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception)
            {
                _ = MessageBox.Show("Please Pick a Sale and a Date!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        // -------------------------------------------------------------------------------
        // B3 Button
        private void Display_btn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Admin == 1)
                {
                    UpdateTime();

                    bool Daily = (bool)dailyRBtn.IsChecked;
                    bool Monthly = (bool)monthlyRBtn.IsChecked;
                    bool Yearly = (bool)yearlyRBtn.IsChecked;
                    // Add Data from the database to display
                    if (Daily)
                    {
                        Sale = Period.DAY;
                        year = managementDatePicker.SelectedDate.Value.Year;
                        month = managementDatePicker.SelectedDate.Value.Month;
                        DataTable tb = manager.DisplayInfos(managementDatePicker.SelectedDate.Value.Day);
                        TextBox sw = managementTxtBox;
                        int i = 0;
                        for (i = 0; i < tb.Columns.Count - 1; i++)
                        {
                            sw.AppendText(tb.Columns[i].ColumnName.PadRight(18));
                        }
                        sw.AppendText(tb.Columns[i].ColumnName.PadRight(18));
                        sw.AppendText("\n");

                        foreach (DataRow row in tb.Rows)
                        {
                            object[] array = row.ItemArray;

                            for (i = 0; i < array.Length - 1; i++)
                            {
                                sw.AppendText(array[i].ToString().PadRight(18));
                            }
                            sw.AppendText(array[i].ToString().PadRight(18));
                            sw.AppendText("\n");
                        }
                    }
                    else if (Monthly)
                    {
                        Sale = Period.MONTH;
                        year = managementDatePicker.SelectedDate.Value.Year;
                        DataTable tb = manager.DisplayInfos(managementDatePicker.SelectedDate.Value.Month);
                        TextBox sw = managementTxtBox;
                        int i = 0;
                        for (i = 0; i < tb.Columns.Count - 1; i++)
                        {
                            sw.AppendText(tb.Columns[i].ColumnName.PadRight(18));
                        }
                        sw.AppendText(tb.Columns[i].ColumnName.PadRight(18));
                        sw.AppendText("\n");

                        foreach (DataRow row in tb.Rows)
                        {
                            object[] array = row.ItemArray;

                            for (i = 0; i < array.Length - 1; i++)
                            {
                                sw.AppendText(array[i].ToString().PadRight(18));
                            }
                            sw.AppendText(array[i].ToString().PadRight(18));
                            sw.AppendText("\n");
                        }
                    }
                    else if (Yearly)
                    {
                        Sale = Period.YEAR;
                        DataTable tb = manager.DisplayInfos(managementDatePicker.SelectedDate.Value.Year);
                        TextBox sw = managementTxtBox;
                        int i = 0;
                        for (i = 0; i < tb.Columns.Count - 1; i++)
                        {
                            sw.AppendText(tb.Columns[i].ColumnName.PadRight(18));
                        }
                        sw.AppendText(tb.Columns[i].ColumnName.PadRight(18));
                        sw.AppendText("\n");

                        foreach (DataRow row in tb.Rows)
                        {
                            object[] array = row.ItemArray;

                            for (i = 0; i < array.Length - 1; i++)
                            {
                                sw.AppendText(array[i].ToString().PadRight(18));
                            }
                            sw.AppendText(array[i].ToString().PadRight(18));
                            sw.AppendText("\n");
                        }
                    }
                    else
                    {
                        _ = MessageBox.Show("Please Pick a Sale and a Date!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                else
                {
                    Validation validate = new Validation();
                    validate.Show();
                    Close();
                }
            }
            catch (Exception)
            {
                _ = MessageBox.Show("Please Pick a Sale and a Date!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        
       
        // -------------------------------------------------------------------------------
        // Print Method On Order Tab
        private void print_btn_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                // TODO: Save To Database
                UpdateTime();
                for (int i = 0; i < coffeeCounter; i++)
                {
                    orderSummaryTextBox.AppendText(AddToOrder[i].TotalOrderSummary("") + "\n");
                }
                manager.SaveToDB();
                double total = 0;
                for (int i = 0; i < coffeeCounter; i++)
                {
                    total += AddToOrder[i].TotalOrderSummary();
                }
                orderSummaryTextBox.AppendText("-----------------------------------------------------------------------------------------\nTotal: R" + total);
                coffeeCounter = 0;
            }
            catch (Exception)
            {
                _ = MessageBox.Show("Please Pick a Sale and a Date!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        //  ---------------------------------------------------------------------------------
        // Order TAB
        // Add to Order
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Admin == 1)
                {
                    bool Daily = (bool)dailyRBtn.IsChecked;
                    bool Monthly = (bool)monthlyRBtn.IsChecked;
                    bool Yearly = (bool)yearlyRBtn.IsChecked;

                    if (Daily)
                    {
                        Sale = Period.DAY;
                        year = managementDatePicker.SelectedDate.Value.Year;
                        month = managementDatePicker.SelectedDate.Value.Month;
                        manager.SaveToTXT(managementDatePicker.SelectedDate.Value.Day);
                        _ = MessageBox.Show("Daily Data Saved to BackUpSale.txt", "Saved!", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else if (Monthly)
                    {
                        Sale = Period.MONTH;
                        year = managementDatePicker.SelectedDate.Value.Year;
                        manager.SaveToTXT(managementDatePicker.SelectedDate.Value.Month);
                        _ = MessageBox.Show("Monthly Data Saved to BackUpSale.txt", "Saved!", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else if (Yearly)
                    {
                        Sale = Period.YEAR;
                        manager.SaveToTXT(managementDatePicker.SelectedDate.Value.Year);
                        _ = MessageBox.Show("Yearly Data Saved to BackUpSale.txt", "Saved!", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        _ = MessageBox.Show("Please Pick a Sale and a Date!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                else
                {
                    Validation validate = new Validation();
                    validate.Show();
                    Close();
                }
            }
            catch (Exception)
            {
                _ = MessageBox.Show("Please Pick a Sale and a Date!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }


           


        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            bool ValidOrder = true;
            string TypeOfCoffee = "";
            // Type of Coffee
            try
            {
                switch (descriptionCoffee.SelectedIndex)
                {
                    case 1:
                        TypeOfCoffee = "Late";
                        break;
                    case 2:
                        TypeOfCoffee = "Cappuccino";
                        break;
                    case 3:
                        TypeOfCoffee = "Americano";
                        break;
                    case 4:
                        TypeOfCoffee = "Espresso";
                        break;
                    case 5:
                        TypeOfCoffee = "Machiato";
                        break;
                    default:
                        ValidOrder = false;
                        throw new();
                }
                ValidOrder = true;
            }
            catch (Exception)
            {
                _ = MessageBox.Show("Choose a Type of Coffee", "Alert!", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            string SizeOfCoffee = "";
            // Size of Coffee
            try
            {
                if ((bool)smallSizeRadioButton.IsChecked)
                {
                    SizeOfCoffee = "Small";
                    if (ValidOrder) ValidOrder = true;

                }
                else if ((bool)mediumSizeRadioButton.IsChecked)
                {
                    SizeOfCoffee = "Medium";
                    if (ValidOrder) ValidOrder = true;
                }
                else if ((bool)largeSizeRadioButton.IsChecked)
                {
                    SizeOfCoffee = "Large";
                    if (ValidOrder) ValidOrder = true;
                }
                else
                {
                    ValidOrder = false;
                    throw new();
                }
            }
            catch (Exception)
            {
                _ = MessageBox.Show("Choose the Size of Coffee", "Alert!", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            int Quantity = quanintyAmount.SelectedIndex;
            // Quantity
            try
            {
                if (ValidOrder) ValidOrder = true;
                if (Quantity == 0)
                {
                    ValidOrder = false;
                    throw new();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Choose the Quantity of Coffee's", "Alert!", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            string AddedIngredients = "no Added Ingredients";
            if ((bool)addedIngredientsCream.IsChecked)
            {
                AddedIngredients = "Added Cream";
            }

            if ((bool)addedIngredientsSugar.IsChecked)
            {
                AddedIngredients = "Added Sugar";
            }

            if ((bool)addedIngredientsSugar.IsChecked && (bool)addedIngredientsCream.IsChecked)
            {
                AddedIngredients = "Added Sugar and Cream";
            }

            // Price of Coffee
            double Price = 0.0;
            try
            {
                // Check the price
                string connectionString = ConfigurationManager.ConnectionStrings["SummativePRG_Final_.Properties.Settings.CoffeeShopeDBConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionString);
                if (con.State != ConnectionState.Open) con.Open();

                string Coffee = "SELECT * FROM CoffeePriceTable";

                SqlCommand CoffeePriceTable = new SqlCommand(Coffee, con);
                SqlDataReader rd = CoffeePriceTable.ExecuteReader();

                while (rd.Read())
                {
                    if (rd["Coffee_Type"].Equals(TypeOfCoffee))
                    {
                        if (SizeOfCoffee == "Small")
                        {
                            Price = (double)(decimal)rd["Small_Price"];
                        }
                        else if (SizeOfCoffee == "Medium")
                        {
                            Price = (double)(decimal)rd["Medium_Price"];
                        }
                        else
                        {
                            Price = (double)(decimal)rd["Large_Price"];
                        }
                    }
                }

                if (con.State != ConnectionState.Closed) con.Close();

            }
            catch (Exception)
            {
                _ = MessageBox.Show("Servers are down", "Error!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            try
            {
                if (coffeeCounter < 7 && ValidOrder)
                {
                    AddToOrder[coffeeCounter] = new Order(TypeOfCoffee, Price, SizeOfCoffee, Quantity, AddedIngredients);
                    _ = MessageBox.Show("Order successfully placed!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    coffeeCounter++;
                }
                else if (ValidOrder)
                {
                    _ = MessageBox.Show("Max Orders Placed", "Alert!", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    throw new();
                }
            }
            catch (Exception)
            {
                _ = MessageBox.Show("Your Order Placed is Impossible to make!", "Warning", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    
}
