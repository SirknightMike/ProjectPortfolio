﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SummativePRG_Final_
{
    public class Order: Interface1
    {
        
            // Variables
            protected string TypeOfCoffee;
            protected double Price;
            protected string SizeOfCoffee;
            protected int Quantity;
            protected string AddedIngredients;

            // Constructor
            public Order()
            {
                TypeOfCoffee = "";
                Price = 0.0;
                SizeOfCoffee = "";
                Quantity = 0;
                AddedIngredients = "";
            }
            public Order(string typeOfCoffee, double price, string sizeOfCoffee, int quantity, string addedIngredients)
            {
                TypeOfCoffee = typeOfCoffee;
                Price = price;
                SizeOfCoffee = sizeOfCoffee;
                Quantity = quantity;
                AddedIngredients = addedIngredients;
            }

            // Getters
            public string GetTypeOfCoffee()
            {
                return TypeOfCoffee;
            }
            public double GetPrice()
            {
                return Price;
            }
            public string GetSizeOfCoffee()
            {
                return SizeOfCoffee;
            }
            public int GetQuantity()
            {
                return Quantity;
            }
            public string GetAddedIngredients()
            {
                return AddedIngredients;
            }

            // Setters
            public void SetTypeOfCoffee(string typeOfCoffee)
            {
                TypeOfCoffee = typeOfCoffee;
            }
            public void SetPrice(double price)
            {
                Price = price;
            }
            public void SetSizeOfCoffee(string sizeOfCoffee)
            {
                SizeOfCoffee = sizeOfCoffee;
            }
            public void SetQuantity(int quantity)
            {
                Quantity = quantity;
            }
            public void SetAddedIngredients(string addedIngredients)
            {
                AddedIngredients = addedIngredients;
            }

            // Virtual Method
            public virtual double TotalOrderSummary()
            {
                return Price * Quantity;
            }

            // Overloaded Method
            public virtual string TotalOrderSummary(string txt)
            {
                return Quantity.ToString().PadRight(22) + " | " + TypeOfCoffee + ", " + SizeOfCoffee + " and " + AddedIngredients + "\t | R" + Price + " | R" + TotalOrderSummary();
            }
        }

        class Manager : Order
        {
            // Overloaded Methods
            public override double TotalOrderSummary()
            {
                return base.TotalOrderSummary();
            }

            public override string TotalOrderSummary(string txt)
            {
                return base.TotalOrderSummary("");
            }

            // View Information
            public DataTable DisplayInfos(int period)
            {
                return SalesTable(period);
            }
            // Save Information to TXT Files
            public void SaveToTXT(int period)
            {
                string path = "BackUpScale.txt";
                using (FileStream fs = new FileStream(path, FileMode.Append, FileAccess.Write))
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    DataTable tb = SalesTable(period);
                    int i = 0;
                    for (i = 0; i < tb.Columns.Count - 1; i++)
                    {
                        sw.Write(tb.Columns[i].ColumnName.PadRight(15));
                    }
                    sw.Write(tb.Columns[i].ColumnName.PadRight(15));
                    sw.WriteLine();

                    foreach (DataRow row in tb.Rows)
                    {
                        object[] array = row.ItemArray;

                        for (i = 0; i < array.Length - 1; i++)
                        {
                            sw.Write(array[i].ToString().PadRight(15));
                        }
                        sw.Write(array[i].ToString().PadRight(15));
                        sw.WriteLine();
                    }
                }

            }
            // Save to DB
            public void SaveToDB()
            {
                // TODO: Add Save to DB Code
                string connectionString = ConfigurationManager.ConnectionStrings["SummativePRG_Final_.Properties.Settings.CoffeeShopeDBConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionString);
                if (con.State != ConnectionState.Open) con.Open();

                // Get Id
                string id = "SELECT Id_Sale FROM SalesTable";

                SqlCommand ID = new SqlCommand(id, con);
                SqlDataReader rd = ID.ExecuteReader();
                int CurrentId = 0;

                while (rd.Read())
                {
                    CurrentId = (int)rd["Id_Sale"];
                }
                rd.Close();

                for (int i = 0; i < MainWindow.coffeeCounter; i++)
                {

                    // Sales Insertion
                    SqlCommand SalesInsertion = new SqlCommand(null, con);
                    SalesInsertion.CommandText = "INSERT INTO SalesTable(Id_Sale, Quantity, Description, Price, Total, date) VALUES (@Id_Sale, @Quantity, @Description, @Price, @Total, @date)";

                    SqlParameter idParem = new SqlParameter("@Id_Sale", SqlDbType.Int, 50);
                    SqlParameter QuanParem = new SqlParameter("@Quantity", SqlDbType.Int, 50);
                    SqlParameter DescParem = new SqlParameter("@Description", SqlDbType.VarChar, 50);
                    SqlParameter PriceParem = new SqlParameter("@Price", SqlDbType.Money, 50);
                    SqlParameter TotParem = new SqlParameter("@Total", SqlDbType.Money, 50);
                    SqlParameter DateParem = new SqlParameter("@date", SqlDbType.Date, 50);

                    idParem.Value = ++CurrentId;
                    QuanParem.Value = MainWindow.AddToOrder[i].GetQuantity();
                    DescParem.Value = MainWindow.AddToOrder[i].GetTypeOfCoffee();
                    PriceParem.Value = MainWindow.AddToOrder[i].GetPrice();
                    TotParem.Value = MainWindow.AddToOrder[i].TotalOrderSummary();
                    DateParem.Value = DateTime.Now.ToString().Split(' ')[0];

                    SalesInsertion.Parameters.Add(idParem);
                    SalesInsertion.Parameters.Add(QuanParem);
                    SalesInsertion.Parameters.Add(DescParem);
                    SalesInsertion.Parameters.Add(PriceParem);
                    SalesInsertion.Parameters.Add(TotParem);
                    SalesInsertion.Parameters.Add(DateParem);

                    SalesInsertion.Prepare();
                    SalesInsertion.ExecuteNonQuery();
                }
                if (con.State != ConnectionState.Closed) con.Close();
            }
            // Retrieve all data from salesTable in the DB
            private DataTable SalesTable(int period)
            {
                string connectionString = ConfigurationManager.ConnectionStrings["SummativePRG_Final_.Properties.Settings.CoffeeShopeDBConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionString);
                if (con.State != ConnectionState.Open) con.Open();

                DataTable tb = new DataTable();
                tb.Clear();
                tb.Columns.Add("Id_Sale");
                tb.Columns.Add("Quantity");
                tb.Columns.Add("Description");
                tb.Columns.Add("Price");
                tb.Columns.Add("Total");
                tb.Columns.Add("date");

                string info = "SELECT * FROM SalesTable";

                SqlCommand Data = new SqlCommand(info, con);
                SqlDataReader rd = Data.ExecuteReader();

                while (rd.Read())
                {
                    if (MainWindow.Sale == MainWindow.Period.DAY) // Daily
                    {
                        if (DateTime.Parse(rd["date"].ToString()).Date.Day == period && DateTime.Parse(rd["date"].ToString()).Date.Year == MainWindow.year && DateTime.Parse(rd["date"].ToString()).Date.Month == MainWindow.month)
                        {
                            DataRow _row = tb.NewRow();
                            _row["Id_Sale"] = rd["Id_Sale"];
                            _row["Quantity"] = rd["Quantity"];
                            _row["Description"] = rd["Description"];
                            _row["Price"] = rd["Price"];
                            _row["Total"] = rd["Total"];
                            _row["date"] = rd["date"].ToString().Split(' ')[0];

                            tb.Rows.Add(_row);
                        }

                    }
                    else if (MainWindow.Sale == MainWindow.Period.MONTH) // Monthly
                    {
                        if (DateTime.Parse(rd["date"].ToString()).Date.Month == period && DateTime.Parse(rd["date"].ToString()).Date.Year == MainWindow.year)
                        {
                            DataRow _row = tb.NewRow();
                            _row["Id_Sale"] = rd["Id_Sale"];
                            _row["Quantity"] = rd["Quantity"];
                            _row["Description"] = rd["Description"];
                            _row["Price"] = rd["Price"];
                            _row["Total"] = rd["Total"];
                            _row["date"] = rd["date"].ToString().Split(' ')[0];

                            tb.Rows.Add(_row);
                        }
                    }
                    else // yearly
                    {
                        if (DateTime.Parse(rd["date"].ToString()).Date.Year == period)
                        {
                            DataRow _row = tb.NewRow();
                            _row["Id_Sale"] = rd["Id_Sale"];
                            _row["Quantity"] = rd["Quantity"];
                            _row["Description"] = rd["Description"];
                            _row["Price"] = rd["Price"];
                            _row["Total"] = rd["Total"];
                            _row["date"] = rd["date"].ToString().Split(' ')[0];

                            tb.Rows.Add(_row);
                        }
                    }
                }
                if (con.State != ConnectionState.Closed) con.Close();
                return tb;
            }
        }
    
}
