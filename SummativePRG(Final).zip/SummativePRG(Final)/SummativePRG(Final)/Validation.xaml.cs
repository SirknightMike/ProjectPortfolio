﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SummativePRG_Final_
{
    /// <summary>
    /// Interaction logic for Validation.xaml
    /// </summary>
    public partial class Validation : Window
    {
        public Validation()
        {
            InitializeComponent();
        }


        private void Register_Click(object sender, RoutedEventArgs e)
        {

            // TODO: Register People
            string username = userNameTxt.Text;
            string password = passwordTxt.Text;

            string connectionString = ConfigurationManager.ConnectionStrings["SummativePRG_Final_.Properties.Settings.CoffeeShopeDBConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            if (con.State != System.Data.ConnectionState.Open) con.Open();

            string user = "SELECT Id_Man, Username FROM ManagerTable";


            SqlCommand userexist = new SqlCommand(user, con);
            SqlDataReader rd = userexist.ExecuteReader();
            bool newUser = false;
            int ID = 0;
            if (username != "")
            {
                while (rd.Read())
                {
                    if (rd["Username"].Equals(username))
                    {
                        newUser = false;
                        break;
                    }
                    else
                    {
                        newUser = true;
                    }
                    ID = (int)rd["Id_Man"];
                }

                rd.Close();
                if (newUser)
                {
                    string newQuery = "INSERT INTO ManagerTable(Id_Man, Username, Password) VALUES ('" + (ID + 1) + "','" + username + "','" + password + "')";
                    SqlCommand newUserCmd = new SqlCommand(newQuery, con);
                    int rowCount = newUserCmd.ExecuteNonQuery();
                    if (rowCount > 0)
                    {
                        MessageBox.Show("Successfully added user.\nUsername: " + username + "\nPassword: " + password, "Login Details", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                else
                {
                    MessageBox.Show("User Already Exists!", "User Exist", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                newUser = false;
                MessageBox.Show("Username Can't be Empty!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            if (con.State != System.Data.ConnectionState.Closed) con.Close();
        }

        private void confirmBtn_Click(object sender, RoutedEventArgs e)
        {
            string username = userNameTxt.Text;
            string password = passwordTxt.Text;

            string connectionString = ConfigurationManager.ConnectionStrings["SummativePRG_Final_.Properties.Settings.CoffeeShopeDBConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            if (con.State != System.Data.ConnectionState.Open) con.Open();

            string user = "SELECT Username, Password FROM ManagerTable";

            SqlCommand userexist = new SqlCommand(user, con);
            SqlDataReader rd = userexist.ExecuteReader();
            int isValid = 0;

            while (rd.Read())
            {
                if (rd["Username"].Equals(username))
                {
                    if (rd["Password"].Equals(password))
                    {
                        MainWindow mainWindow = new MainWindow();
                        mainWindow.Show();
                        MainWindow.Admin = 1;
                        isValid = 1;
                        MessageBox.Show("Successfully Loged in!", "Welcome", MessageBoxButton.OK, MessageBoxImage.Information);
                        Close();
                    }
                }
            }
    }
    }
}
